﻿namespace FDDSE.ConsoleClient.Models
{
    class FdcpSerial : IFdcpSerial
    {
        public string Stuff()
        {
            throw new System.NotImplementedException();
        }
    }
}